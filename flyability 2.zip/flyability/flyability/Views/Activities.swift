//
//  Activities.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI
import SwiftUIMargin
struct Activities: View {
    var body: some View {
       
        VStack{
        ZStack {
                Wave()
                        
            ZStack{
                HStack{
                    Text("Out Doors")
                    .font(.system(size: 35))
                    .fontWeight(.bold)
                    .foregroundColor(Color("darkgray"))
                   // Spacer()
                    Button("Outdoors") {}
                        .font(.system(size: 25))
                        .fontWeight(.semibold)
                        .foregroundColor(Color.white)
                        .frame(width:120,height: 40)
                        .background(Color("bluee"))
                        .cornerRadius(10)
                        
                }//HStack line 18
                
                .margin(top:300,right: 70)
                
        ZStack{
            Button{print("test")}
                label:{
                    HStack{
                        NavigationLink(destination:ActivityPage()  ){
                            Image("out1")
                            .resizable()}
                            .frame(width:115,height: 120)
                    } //HStack line 31
                }//label
                .margin(right:240)
            Button{print("test")}
        label:{
            HStack{
                NavigationLink(destination:ActivityPage()  ){
                    Image("out3")
                    .resizable()}
                    .frame(width:115,height: 120)
            } //HStack line 31
        }//label
        .margin(left:240)
            
            Button{print("test")}
                label:{
                    HStack{
                        NavigationLink(destination:ActivityPage()  ){
                            Image("out2")
                            .resizable()}
                            .frame(width:145,height: 160)
                    } //HStack line 31
                }//label

            
            }//Zstack line 36
        .margin(top:550)
                            
                         
                
            HStack{
                    Text("In Doors")
                    .font(.system(size: 35))
                    .fontWeight(.bold)
                    .foregroundColor(Color("darkgray"))
                   // Spacer()
                    Button("Indoors") {}
                        .font(.system(size: 25))
                        .fontWeight(.semibold)
                        .foregroundColor(Color.white)
                        .frame(width:120,height: 40)
                        .background(Color("bluee"))
                        .cornerRadius(10)
                        
                }//HStack line 71
                
                .margin(top:800,right: 80)
                
        ZStack{
            Button{print("test")}
                label:{
                    HStack{
                        NavigationLink(destination:ActivityPage2()  ){
                            Image("in1")
                            .resizable()}
                            .frame(width:115,height: 120)
                    } //HStack line 31
                }//label
                .margin(right:240)
            Button{print("test")}
                label:{
                    HStack{
                        NavigationLink(destination:ActivityPage()  ){
                            Image("in3")
                            .resizable()}
                            .frame(width:115,height: 120)
                    } //HStack line 31
                }//label
                .margin(left:240)
                    
            Button{print("test")}
                label:{
                    HStack{
                        NavigationLink(destination:ActivityPage()  ){
                            Image("in2")
                            .resizable()}
                            .frame(width:145,height: 160)
                            } //HStack line 31
                        }//label
                    }//Zstack line 36
                .margin(top:1050)
                
                
                
                
                
                        } //Zstack line18
                        
                Image("PA2")
                    .margin(right: 180)
                Text("Activities")
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.white)
                    .margin(top: 180,right: 215)
                Image(systemName:"video.slash.fill")
                    .resizable()
                    .frame(width: 40, height: 30)
                    .foregroundColor(Color("darkblue"))
                    .margin(top: 90,right: 85)
            Image(systemName:"mic.fill")
                .resizable()
                .frame(width: 30, height: 50)
                .foregroundColor(Color("darkblue"))
                .margin(top:1300,left: 290)
                }//Z Stack
                        
                        .frame(height: 200)
                                Spacer()
                      
                     
                            } //VStack
                  // .navigationTitle("My Trip Plan")
                   
                   //  .foregroundColor(Color.gray)
                        }
    }


struct Activities_Previews: PreviewProvider {
    static var previews: some View {
        Activities()
    }
}
