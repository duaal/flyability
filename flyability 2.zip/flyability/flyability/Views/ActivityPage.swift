//
//  ActivityPage.swift
//  flyability
//
//  Created by duaa mohammed on 03/11/2022.
//

import SwiftUI
import SwiftUIMargin
struct ActivityPage: View {
    var body: some View {
        VStack{
            ZStack{
                Image("nature2")
                    .frame(height: 70)
                    .margin(bottom: 100)
                
                Image("PA2")
                    .frame(height: 0)
                    .margin(bottom:10 , right: 200 )
                Image(systemName:"video.slash.fill")
                    .resizable()
                    .frame(width: 40 , height: 30)
                    .margin(top: 70,right: 100)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
            }
            Text("Matterhorn")
                .padding(/*@START_MENU_TOKEN@*/.horizontal/*@END_MENU_TOKEN@*/)
                .margin(top: 50 , right: 200)
                .font(.title)
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
            
            
            Text("The Matterhorn is one of the most famouspeaks of the Apennine Mountains in the European Alps. It stretches on the borders of Switzerland and Italy and rises above the Swiss village of Zermatt and the Italian village of Breuil-Cervinia in the Val Tournanche valley. ")
                .padding(/*@START_MENU_TOKEN@*/[.top, .leading, .trailing]/*@END_MENU_TOKEN@*/)
               
                .margin()
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
                
            Button("Out Door") {
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
            }
            .frame(width: 70, height: 1)
            .padding()
            .background(Color(red: 0.902, green: 0.902, blue: 0.902))
            .clipShape(Capsule())
            .offset(x:40 , y:-170)
            HStack{
                Button("With Assistant") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .frame(width: 120, height: 9)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.309, green: 0.443, blue: 0.772))
                .clipShape(Capsule())
                .offset(x:-20 , y:-30)
               
                Button("Without Assistant") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .frame(width: 150, height: 9)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.309, green: 0.443, blue: 0.772))
                .clipShape(Capsule())
                .offset(x:-20 , y:-30)
            }
            
            Text("Available Time")
                .offset(x:-100 , y:-30)
                .font(.title)
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
            HStack{
                Button("Oct 20 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
                
                Button("Oct 22 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
                
                Button("Oct 23 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
            }
            NavigationLink(destination:ReservationConfirm().navigationBarBackButtonHidden(true)){
                Text("Book this Activity")}
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
            
            .font(.title2)
            .frame(width: 200, height: 5)
            .padding()
            .foregroundColor(Color.white)
            .background(Color(red: 0.309, green: 0.443, blue: 0.772))
            .offset(x:0, y:-10)
        }
    }
}

struct ActivityPage_Previews: PreviewProvider {
    static var previews: some View {
        ActivityPage()
    }
}
