//
//  ActivityPage2.swift
//  flyability
//
//  Created by duaa mohammed on 03/11/2022.
//

import SwiftUI

struct ActivityPage2: View {
    var body: some View {
        VStack{
            Image("spa")
                .frame(height: 70)
            .offset(x:0 , y:-20)
            
            Image("PA2")
                .frame(height: 0)
            .offset(x:-90 , y:10)
            Image(systemName:"video.slash.fill")
            .resizable()
            .frame(width: 40 , height: 30)
            .offset(x:-40 , y:30)
            .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
            
            Text(" O'Kari SPA ")
                .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                .offset(x:-100 , y:60)
                .font(.title)
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
            
            
            Text("To bring the age-old traditions of the Hammam (steam room) to modern life, and to transmit the precious values of this practice to other women – these are the desires that motivated Karisma Lasfar to share her culture and its history. ")
                .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                .offset(x:10 , y:20)
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
                
            Button("In Door") {
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
            }
            .frame(width: 70, height: 1)
            .padding()
            .background(Color(red: 0.902, green: 0.902, blue: 0.902))
            .clipShape(Capsule())
            .offset(x:40 , y:-150)
            HStack{
                Button("With Assistant") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .frame(width: 120, height: 9)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.309, green: 0.443, blue: 0.772))
                .clipShape(Capsule())
                .offset(x:-20 , y:-30)
               
                Button("Without Assistant") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .frame(width: 150, height: 9)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.309, green: 0.443, blue: 0.772))
                .clipShape(Capsule())
                .offset(x:-20 , y:-30)
            }
            
            Text("Available Time")
                .offset(x:-100 , y:-30)
                .font(.title)
                .fontWeight(.thin)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
            HStack{
                Button("Oct 20 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
                
                Button("Oct 22 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
                
                Button("Oct 23 \n 2:00 pm 6:00pm") {
                   
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .font(.title3)
                .frame(width: 90.0, height: 74.0)
                .padding()
                .foregroundColor(Color.white)
                .background(Color(red: 0.538, green: 0.558, blue: 0.932))
               
                .offset(x:-1 , y:-30)
            }
            
            Button("Book this Activity") {
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
            }
            .font(.title2)
            .frame(width: 200, height: 5)
            .padding()
            .foregroundColor(Color.white)
            .background(Color(red: 0.309, green: 0.443, blue: 0.772))
            .offset(x:0, y:-10)
        }
    }
}

struct ActivityPage2_Previews: PreviewProvider {
    static var previews: some View {
        ActivityPage2()
    }
}
