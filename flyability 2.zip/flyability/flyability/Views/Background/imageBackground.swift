//
//  imageBackground.swift
//  flyability
//
//  Created by duaa mohammed on 26/10/2022.
//

import SwiftUI

struct imageBackground: View {
    var body: some View {
        VStack(){
            VStack{Image("wave").resizable().frame( width:768.96,height: 268)
                Spacer()
            }
                .ignoresSafeArea()
            
        }
    }
}

struct imageBackground_Previews: PreviewProvider {
    static var previews: some View {
        imageBackground()
    }
}
