//
//  imageBackground2.swift
//  flyability
//
//  Created by duaa mohammed on 26/10/2022.
//

import SwiftUI

struct imageBackground2: View {
    var body: some View {
    
        Image("wave (1)").ignoresSafeArea()
            
           
            
            
    }
}

struct imageBackground2_Previews: PreviewProvider {
    static var previews: some View {
        imageBackground2()
    }
}
