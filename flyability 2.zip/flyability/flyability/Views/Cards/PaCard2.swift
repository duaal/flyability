//
//  PaCard2.swift
//  flyability
//
//  Created by duaa mohammed on 26/10/2022.
//

import SwiftUI
import SwiftUIMargin
struct PaCard2: View {
    var name: String
    var description: String
    var body: some View {
        HStack{
            
            VStack(alignment:.leading){
                Text(name).font(.custom("SF-Pro", size: 13)).foregroundColor(Color("FontColor")).padding(.bottom,1)
                Text( description).font(.custom("Helvetica",size: 10)).fontWeight(.light)
            }.padding()
            Spacer()
        }.padding().background(
            Rectangle()
                .fill(Color.white).padding(4)
                .shadow(
                    color: Color.gray.opacity(0.15),
                    radius: 10,
                    x: 0,
                    y:8
                 )
        ).margin(bottom: 15)}
    }
    
    struct PaCard2_Previews: PreviewProvider {
        static var previews: some View {
            PaCard2(name: "some name", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ").font(.system(size: 13))
        }
    }
