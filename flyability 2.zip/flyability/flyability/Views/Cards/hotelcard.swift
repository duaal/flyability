//
//  hotelcard.swift
//  flyability
//
//  Created by duaa mohammed on 27/10/2022.
//

import SwiftUI
import SwiftUIMargin
struct hotelcard: View {
    var name:String
    var location:String
    var price:String
    var image :String
    
    var body: some View {
        VStack{
            Image(image)
            HStack(alignment:.firstTextBaseline){
                VStack(alignment:.leading){Text(name).font(.custom("Helvetica", size: 12)).bold()
                    Text(location).font(.custom("Helvetica", size: 7)).fontWeight(.regular)
                    Text("show in map").font(.custom("Helvetica", size: 7)).bold()
                }.margin(top: 10,bottom: 16).padding().margin(right: 20)
                VStack{Text("Price").font(.custom("Helvetica", size: 12)).fontWeight(.light)
                    Text(price).font(.custom("Helvetica", size: 12)).bold()}.margin(top: 10,bottom: 16).padding()
                VStack(alignment:.leading){Text("Reviews").font(.custom("Helvetica", size: 12)).fontWeight(.light)
                    Text("8.5").foregroundColor(Color("rating")).font(.custom("Helvetica", size: 12)).bold()}.margin(top: 10,bottom: 16).padding()
                
            }.frame(width: 300,height: 50)
            
        }.frame(width: 300).background(Color("cardBackground")).margin(top: 15)
    }
}

struct hotelcard_Previews: PreviewProvider {
    static var previews: some View {
        hotelcard(name: "hotel name", location: "this is the hotel location", price: "560$",image: "hotel1")
    }
}
