//
//  FaceId.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI
import LocalAuthentication
struct FaceId: View {
    @State private var nav = false
    @State private var unlock = false
    @State private var text = "locked"
    @State private var apper = true

    var body: some View {
        if nav{
            afterwaiting()
        }else{
            VStack{
                
                Text(text).bold()
                
            }.background(Image("wavebg")).onAppear(perform: self.authentication)
        }}
    func  authentication(){
        let context=LAContext()
        var error:NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error){
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "this is for securty resons"){success,authenticationError in
                if success{
                   nav = true
                }else{
                    text="there is a problem"
                }
                
            }
        }
        else{
            text="this phone doesn't support face id"
        }
    }
}


struct FaceId_Previews: PreviewProvider {
    static var previews: some View {
        FaceId()
    }
}
