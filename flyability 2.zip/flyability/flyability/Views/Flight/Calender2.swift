//
//  Calender2.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

//
//  Calender.swift
//  Level 1
//
//  Created by Razan Aldossari on 06/04/1444 AH.
//

import SwiftUI
import SwiftUIMargin
extension View {
  @ViewBuilder func applyTextColor2(_ color: Color) -> some View {
    if UITraitCollection.current.userInterfaceStyle == .light {
      self.colorInvert().colorMultiply(color)
    } else {
      self.colorMultiply(color)
    }
  }
}

struct Calender2: View {
@State var selectedDate: Date = Date()
var body: some View {

VStack{
    ZStack {
        Wave()
        
        ZStack{
            
            DatePicker("Select Date", selection: $selectedDate, displayedComponents: [.date])
                .padding(.horizontal)
                .datePickerStyle(.graphical)
            //  .applyTextColor(.white)
                .accentColor(Color("purple"))
                .background(Color("softblue").opacity(4.0), in: RoundedRectangle(cornerRadius: 5))
                .padding(20)
                .margin(top:650)
            NavigationLink (destination: HotleList()){ Text("Search")}
                    .font(.system(size: 35))
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                    .frame(width:340,height: 50)
                    .background(Color("darkblue"))
                    .cornerRadius(15)
                    .margin(top:1225)
            
                      
        } //Zstack line18
                  
      Image(systemName:"mic.fill")
          .resizable()
          .frame(width: 30, height: 50)
          .foregroundColor(Color("darkblue"))
          .margin(top:1330,left: 300)
        Image("camera")
            .resizable()
            .frame(width: 140,height: 140)
            .margin(right: 200)
        Image("user")
            .margin(bottom:25,left: 160)
        Text("Choose a Date")
                .font(.title)
                .fontWeight(.heavy)
                .foregroundColor(Color.white)
                .margin(top: 180,right: 145)
        Image(systemName:"video.slash.fill")
            .resizable()
            .frame(width: 40, height: 30)
            .foregroundColor(Color("darkblue"))
            .margin(top: 90,right: 120)
    }//ZStack line 12
    
    .frame(height: 200)
            Spacer()
            } //VStack

        } //navigation
    } //body line 11
//struct line 10

struct Calender2_Previews: PreviewProvider {
    static var previews: some View {
        Calender2()
    }
}

