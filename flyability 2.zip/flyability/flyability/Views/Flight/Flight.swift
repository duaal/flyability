//
//  Flight.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct Flight: View {
    var body: some View {
        

VStack{
    ZStack{
     Wave()
                
      ZStack{
        HStack{
            
            Button("Round Trip") {}
            .font(.system(size: 20))
            .fontWeight(.semibold)
            .foregroundColor(Color.white)
            .frame(width:110,height: 40)
            .background(Color("gray"))
            .cornerRadius(10)
            
            Button("One Way") {}
            .font(.system(size: 20))
            .fontWeight(.bold)
            .foregroundColor(Color.white)
            .frame(width:110,height: 40)
            .background(Color("purple"))
            .cornerRadius(10)
            
            Button("Multi-city") {}
            .font(.system(size: 20))
            .fontWeight(.bold)
            .frame(width:110,height: 40)
            .foregroundColor(Color.white)
            .background(Color("gray"))
            .cornerRadius(10)
       
                    } //Hstack line 19
        .margin(top:300)

                
Button{print("test")}
    label:{
        HStack{
        Image(systemName: "airplane.departure")
            .resizable()
            .frame(width: 40, height: 40)
            .foregroundColor(Color("purple"))
            NavigationLink(destination: SearchFour()){
                Text("Flying From")}
            .font(.system(size: 30))
            .fontWeight(.bold)
            .foregroundColor(Color("darkgray"))
                    
                } //HStack line 51
        .margin(right: 90)
                .frame(width:340,height: 50)
                .background(Color("babyblue"))
                .cornerRadius(10)
                
            }//label
            .margin(top:450)
          
Button{print("test")}
    label:{
       HStack{
        Image(systemName: "airplane.arrival")
            .resizable()
            .frame(width: 40, height: 40)
            .foregroundColor(Color("purple"))
                      
        Text("Flying To")
            .font(.system(size: 30))
            .fontWeight(.bold)
            .foregroundColor(Color("darkgray"))
                              
             } //HStack line 73
                .margin(right: 130)
                .frame(width:340,height: 50)
                .background(Color("babyblue"))
                .cornerRadius(10)
                          
            }//label
            .margin(top:570)
          
          
Button{print("test")}
   label:{
    HStack{
        Image(systemName: "calendar")
            .resizable()
            .frame(width: 35, height: 35)
            .foregroundColor(Color("purple"))
        NavigationLink(destination:Calender()){
            Text("Select Dates")}
            .font(.system(size: 30))
            .fontWeight(.bold)
            .foregroundColor(Color("darkgray"))
                                        
        } //HStack line 96
            .margin(right: 80)
            .frame(width:340,height: 50)
            .background(Color("babyblue"))
            .cornerRadius(10)
                                    
        }//label
            .margin(top:690)
          
          
Button{print("test")}
  label:{
    HStack{
     Image(systemName: "person.fill")
            .resizable()
            .frame(width: 30, height: 30)
            .foregroundColor(Color("purple"))
                                
    Text("Teravelers")
            .font(.system(size: 30))
            .fontWeight(.bold)
            .foregroundColor(Color("darkgray"))
                                        
            } //HStack line 119
            .margin(right: 115)
            .frame(width:340,height: 50)
            .background(Color("babyblue"))
            .cornerRadius(10)
                                    
        }//label
            .margin(top:810)
          
Button{print("test")}
label:{
    HStack{
        Image(systemName: "chair.lounge.fill")
            .resizable()
            .frame(width: 30, height: 30)
            .foregroundColor(Color("purple"))
                                
        Text("Preferred class")
            .font(.system(size: 30))
            .fontWeight(.bold)
            .foregroundColor(Color("darkgray"))
                                
        } //HStack line 141
            .margin(right: 50)
            .frame(width:340,height: 50)
            .background(Color("babyblue"))
            .cornerRadius(10)
                                    
            }//label
            .margin(top:930)
          
          NavigationLink(destination: Tickest() ){
              Text("Search")}
                  .font(.system(size: 35))
                  .fontWeight(.bold)
                  .foregroundColor(Color.white)
                  .frame(width:340,height: 50)
                  .background(Color("darkblue"))
                  .cornerRadius(15)
                  .margin(top:1225)
              
          
                } //Zstack line18
                
    Image(systemName:"mic.fill")
        .resizable()
        .frame(width: 30, height: 50)
        .foregroundColor(Color("darkblue"))
        .margin(top:1330,left: 300)
    Image("camera")
        .resizable()
        .frame(width: 140,height: 140)
        .margin(right: 200)
    Image("user")
        .margin(bottom:25,left: 160)
    Text("Flight")
        .font(.title)
        .fontWeight(.heavy)
        .foregroundColor(Color.white)
        .margin(top: 180,right: 255)
    Image(systemName:"video.slash.fill")
        .resizable()
        .frame(width: 40, height: 30)
        .foregroundColor(Color("darkblue"))
        .margin(top: 90,right: 120)
            }//Z Stack
                
        .frame(height: 200)
                        Spacer()
        
              
      } //VStack line 14
                }
    
}

struct Flight_Previews: PreviewProvider {
    static var previews: some View {
        Flight()
    }
}
