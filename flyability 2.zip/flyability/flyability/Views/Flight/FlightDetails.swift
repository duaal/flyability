//
//  FlightDetails.swift
//  flyability
//
//  Created by duaa mohammed on 03/11/2022.
//

import SwiftUI

struct FlightDetails: View {
    var body: some View {
        VStack{
            ZStack{
                
                
                Image(/*@START_MENU_TOKEN@*/"wave"/*@END_MENU_TOKEN@*/)
                
                    .offset(x:0 , y:-130)
                
                Image("camera")
                    .offset(x:-90 , y:-100)
                
                
                Image(systemName:"video.slash.fill")
                    .resizable()
                    .frame(width: 40 , height: 30)
                    .offset(x:-40 , y:-50)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                
                Image("pa33")
                    .offset(x:100 , y:-100)
                
                
            }
            
            Text(/*@START_MENU_TOKEN@*/"Flight Details"/*@END_MENU_TOKEN@*/)
                .font(.title)
                .fontWeight(.thin)
                .multilineTextAlignment(.leading)
                .offset(x:-100 , y: -120)
            
            HStack{
                Image(systemName:"suitcase.fill")
                    .resizable()
                    .frame(width: 50 , height: 50)
                    .offset(x:-20 , y:-100)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                
                Text(/*@START_MENU_TOKEN@*/" 20 kg"/*@END_MENU_TOKEN@*/)
                    .font(.title)
                    .fontWeight(.thin)
                    .offset(x:-20 , y:-100)
            }
            
            HStack{
                Image(systemName:"fork.knife")
                    .resizable()
                    .frame(width: 50 , height: 50)
                    .offset(x:-20 , y:-70)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                
                Text(/*@START_MENU_TOKEN@*/"  1 Meal"/*@END_MENU_TOKEN@*/)
                    .font(.title)
                    .fontWeight(.thin)
                    .offset(x:-20 , y:-70)
            }
            HStack{
                Image(systemName:"clock.fill")
                    .resizable()
                    .frame(width: 50 , height: 50)
                    .offset(x:0 , y:-50)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                
                Text("  Bording \n 6:30")
                    .font(.title)
                    .fontWeight(.thin)
                    .offset(x:0 , y:-50)
            }
            NavigationLink(destination: payment2()){
                Text(" Book ")
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                
                    .font(.title2)
                    .frame(width: 200, height: 5)
                    .padding()
                    .foregroundColor(Color.white)
                    .background(Color(red: 0.309, green: 0.443, blue: 0.772))
                    .offset(x:0, y:-10)
            }
            
            VStack{
                Image(systemName:"mic.fill")
                    .resizable()
                    .frame(width: 20 , height: 30)
                    .offset(x:150 , y:50)
                    .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
            }
            
        }    }
}

struct FlightDetails_Previews: PreviewProvider {
    static var previews: some View {
        FlightDetails()
    }
}
