//
//  FlightSearch.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct FlightSearch: View {
    var body: some View {
      
        ScrollView{
            VStack{
                ZStack{
                 Image("wave (1)").ignoresSafeArea()
                   
                    ZStack{
                        HStack{
                            
                            Button("Round Trip") {}
                                .font(.system(size: 20))
                                .fontWeight(.semibold)
                                .foregroundColor(Color.white)
                                .frame(width:110,height: 40)
                                .background(Color("gray"))
                                .cornerRadius(10)
                            
                            Button("One Way") {}
                                .font(.system(size: 20))
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .frame(width:110,height: 40)
                                .background(Color("purple"))
                                .cornerRadius(10)
                            
                            Button("Multi-city") {}
                                .font(.system(size: 20))
                                .fontWeight(.bold)
                                .frame(width:110,height: 40)
                                .foregroundColor(Color.white)
                                .background(Color("gray"))
                                .cornerRadius(10)
                            
                        } //Hstack line 19
                        .margin(top:290)
                   
                        
                        Button{print("test")}
                    label:{
                        HStack{
                            Image(systemName: "airplane.departure")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(Color("purple"))
                          
                                VStack(alignment: .leading){
                                    Text("Flying From")
                                        .font(.system(size: 27))
                                        .fontWeight(.bold)
                                        .foregroundColor(Color("darkgray"))
                                    Text("RUH")
                                        .font(.system(size: 27))
                                        .fontWeight(.thin)
                                        .foregroundColor(Color("darkgray"))
                                    
                                } //VStack line 56
                            } //HStack line 50
                            .margin(right: 110)
                            .frame(width:340,height: 70)
                            .background(Color("babyblue"))
                            .cornerRadius(10)
                            
                        }//label
                        .margin(top:410)
                        
                        Button{print("test")}
                    label:{
                        HStack{
                            Image(systemName: "airplane.arrival")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(Color("purple"))
                            
                            VStack(alignment: .leading){
                                Text("Flying To")
                                    .font(.system(size: 27))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkgray"))
                                Text("CDG")
                                    .font(.system(size: 27))
                                    .fontWeight(.thin)
                                    .foregroundColor(Color("darkgray"))
                            }//VStack line 84
                        } //HStack line 73
                        .margin(right: 140)
                        .frame(width:340,height: 80)
                        .background(Color("babyblue"))
                        .cornerRadius(10)
                        
                    }//label
                    .margin(top:570)
                        
                        
                        Button{print("test")}
                    label:{
                        HStack{
                            Image(systemName: "calendar")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(Color("purple"))
                            
                            VStack(alignment: .leading){
                                Text("Select Dates")
                                    .font(.system(size: 27))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkgray"))
                                Text("10 OCT")
                                    .font(.system(size: 27))
                                    .fontWeight(.thin)
                                    .foregroundColor(Color("darkgray"))
                            }// VStack line 112
                        } //HStack line 96
                        .margin(right: 100)
                        .frame(width:340,height: 80)
                        .background(Color("babyblue"))
                        .cornerRadius(10)
                        
                    }//label
                    .margin(top:740)
                        
                        
                        Button{print("test")}
                    label:{
                        HStack{
                            Image(systemName: "person.fill")
                                .resizable()
                                .frame(width: 30, height: 30)
                                .foregroundColor(Color("purple"))
                            
                            VStack(alignment: .leading){
                                Text("Teravelers")
                                    .font(.system(size: 27))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkgray"))
                                Text("One person")
                                    .font(.system(size: 27))
                                    .fontWeight(.thin)
                                    .foregroundColor(Color("darkgray"))
                            }//VStack line 140
                        } //HStack line 119
                        .margin(right: 130)
                        .frame(width:340,height: 80)
                        .background(Color("babyblue"))
                        .cornerRadius(10)
                        
                    }//label
                    .margin(top:910)
                        
                        Button{print("test")}
                    label:{
                        HStack{
                            Image(systemName: "chair.lounge.fill")
                                .resizable()
                                .frame(width: 30, height: 30)
                                .foregroundColor(Color("purple"))
                            
                            VStack(alignment: .leading){
                                Text("Preferred class")
                                    .font(.system(size: 27))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkgray"))
                                Text("Economy")
                                    .font(.system(size: 27))
                                    .fontWeight(.thin)
                                    .foregroundColor(Color("darkgray"))
                            }//VStack line 167
                        } //HStack line 141
                        .margin(right: 70)
                        .frame(width:340,height: 80)
                        .background(Color("babyblue"))
                        .cornerRadius(10)
                        
                    }//label
                    .margin(top:1080)
                        NavigationLink(destination:Tickest()){
                            
                            Text("Search")}
                        .font(.system(size: 35))
                        .fontWeight(.bold)
                        .foregroundColor(Color.white)
                        .frame(width:340,height: 50)
                        .background(Color("darkblue"))
                        .cornerRadius(15)
                        .margin(top:1225)
                    
                                
                    } //Zstack line18
                            
                Image(systemName:"mic.fill")
                    .resizable()
                    .frame(width: 30, height: 50)
                    .foregroundColor(Color("darkblue"))
                    .margin(top:1330,left: 300)
                Image("camera")
                    .resizable()
                    .frame(width: 140,height: 140)
                    .margin(right: 200)
                Image("user")
                    .margin(bottom:25,left: 160)
                Text("Flight")
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.white)
                    .margin(top: 180,right: 255)
                Image(systemName:"video.slash.fill")
                    .resizable()
                    .frame(width: 40, height: 30)
                    .foregroundColor(Color("darkblue"))
                    .margin(top: 90,right: 120)
                        }//Z Stack
                            
                    .frame(height: 200)
                                    Spacer()
                    
                          
                  } //VStack line 14
                            }
    }
}

struct FlightSearch_Previews: PreviewProvider {
    static var previews: some View {
        FlightSearch()
    }
}
