//
//  Tickest.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct Tickest: View {
    var body: some View {

        VStack{
         ZStack {
                        
        Wave()
             HStack{
                 
                     //   HStack{
                     Button("WED \n10") {}
                         .font(.title)
                         .fontWeight(.semibold)
                         .foregroundColor(Color.white)
                         .frame(width:80,height: 100)
                         .background(Color("purple"))
                         .cornerRadius(10)
                     
                     Button("WED \n10") {}
                         .frame(width:80,height: 100)
                         .font(.title)
                         .fontWeight(.semibold)
                         .foregroundColor(Color.white)
                         .background(Color("gray"))
                         .cornerRadius(10)
                     
                     Button("WED \n10") {}
                         .frame(width:80,height: 100)
                         .font(.title)
                         .fontWeight(.semibold)
                         .foregroundColor(Color.white)
                         .background(Color("gray"))
                         .cornerRadius(10)
                     
                     Button("WED \n10") {}
                         .frame(width:80,height: 100)
                         .font(.title)
                         .fontWeight(.semibold)
                         .foregroundColor(Color.white)
                         .background(Color("gray"))
                         .cornerRadius(10)
                     
                 } //Hstack line17
                 .margin(top:370)
                 

                 Button{print("test")}
                 
         label:{
             VStack{
             
                     HStack{
                         Text("5:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         
                         Text("6:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         
                     } //Hstack line 59
                     .margin(top:20,left: 10,right: 10)
                     //     .padding(20)
                     
                     HStack{
                         Image(systemName: "circlebadge")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         //       .margin(bottom:100)
                         ZStack{
                             Divider()
                             Image(systemName: "airplane")
                                 .resizable()
                                 .frame(width: 40, height: 40)
                                 .foregroundColor(Color("darkblue"))
                         } //Zstack line 85
                         
                         Spacer()
                         
                         Image(systemName: "circlebadge.fill")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         
                      }//Hstack line 75
                     .padding(20)
                
                     HStack{
                         Text("200$")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         NavigationLink(destination:FlightDetails()){
                             Text("View details")}
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         //  .margin(top:10)
                     }
                     .margin(bottom:20,left: 10,right: 10)
                     //   .padding(20)
                     
                  } //Vstack line 58
                 
              } //label
             .frame(width:340,height: 150)
             //.padding(10)
             .background(Color("babyblue"))
             .cornerRadius(20)
             .margin(top:650)
         
                 
                 Button{print("test")}
                 
             label:{
                 VStack{
                     HStack{
                         Text("5:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         
                         Text("6:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         
                     }//Hstack line 129
                     .margin(top:20,left: 10,right: 10)
                     
                     
                     
                     HStack{
                         Image(systemName: "circlebadge")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         //       .margin(bottom:100)
                         ZStack{
                             Divider()
                             Image(systemName: "airplane")
                                 .resizable()
                                 .frame(width: 40, height: 40)
                                 .foregroundColor(Color("darkblue"))
                         } //Zstack line 152
                         
                         Spacer()
                         
                         Image(systemName: "circlebadge.fill")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         
                     }//Hstack line 146
                     .padding(20)
                     
                     HStack{
                         Text("200$")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         NavigationLink(destination:FlightDetails()){
                             Text("View details")}
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         
                     } //HStack line170
                     .margin(bottom:20,left: 10,right: 10)
                     
                     
                 } //Vstack line 128
                 
             } //label
             .frame(width:340,height: 150)
                 //.padding(10)
             .background(Color("babyblue"))
             .cornerRadius(20)
             .margin(top:960)
                 
                 
                 Button{print("test")}
                 
             label:{
                 VStack{
                     HStack{
                         Text("5:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         
                         Text("6:30")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         
                     }//Hstack line 200
                     .margin(top:20,left: 10,right: 10)
                     
                     //  .padding(20)
                     
                     HStack{
                         Image(systemName: "circlebadge")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         
                         ZStack{
                             Divider()
                             Image(systemName: "airplane")
                                 .resizable()
                                 .frame(width: 40, height: 40)
                                 .foregroundColor(Color("darkblue"))
                         } //Zstack line 223
                         
                         Spacer()
                         
                         Image(systemName: "circlebadge.fill")
                             .resizable()
                             .frame(width: 30, height: 30)
                             .foregroundColor(Color("darkblue"))
                         
                     }//Hstack line 217
                     .padding(20)
                     
                     HStack{
                         Text("200$")
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         Spacer()
                         NavigationLink(destination:FlightDetails()){
                             Text("View details")}
                             .font(.system(size: 20,weight:
                                    .bold,design: .default))
                             .foregroundColor(Color("darkblue"))
                         
                     } //HStack line 241
                     .margin(bottom:20,left: 10,right: 10)
                     
                 } //Vstack line 199
                 
             } //label
             .frame(width:340,height: 150)
                 //.padding(10)
             .background(Color("babyblue"))
             .cornerRadius(20)
             .margin(top:1270)
             
             
             
             Image("camera")
                 .resizable()
                 .frame(width: 140,height: 140)
                 .margin(right: 200)
             Image("user")
                 .margin(bottom:25,left: 160)
               Text("Flight")
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.white)
                    .margin(top: 180,right: 265)
            Image(systemName:"video.slash.fill")
                    .resizable()
                    .frame(width: 45, height: 30)
                    .foregroundColor(Color("darkblue"))
                    .margin(top: 90,right: 120)
                        }//Z Stack line 14
                        
                        .frame(height: 200)
                                Spacer()
                      
                 } //VStack line 13
               } 
    }


struct Tickest_Previews: PreviewProvider {
    static var previews: some View {
        Tickest()
    }
}
