//
//  Wave.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct Wave: View {
    var body: some View {
        Image("wave (1)").ignoresSafeArea()
    }
}

struct Wave_Previews: PreviewProvider {
    static var previews: some View {
        Wave()
    }
}
