//
//  HotleList.swift
//  flyability
//
//  Created by duaa mohammed on 31/10/2022.
//

import SwiftUI

struct HotleList: View {
    struct hotel{
        let id: Int
        let name: String
        let price:String
        let location :String
        let image :String
    }
    
    let hotels = [
        hotel(id: 1, name: "hotel1", price: "400", location: "some location data", image: "hotel1"),
        hotel(id:2, name: "hotel2", price: "200", location: "some location data", image: "hotel2"),
        hotel(id:3,name: "hotel3", price: "500", location: "some location data", image: "hotel3"),
        hotel(id:4,name: "hotel4", price: "600", location: "some location data", image: "hotel1"),

     ]
    var body: some View {
     
    
            VStack{
                ZStack(alignment:.leading ){
                    
                    imageBackground2()
                    VStack(alignment:.leading){
                    Image("camera").margin(left: 20)
                        HStack(alignment:.lastTextBaseline){
                            Text("Hotel").font(.custom("Helvetica", size: 31)).bold().foregroundColor(Color.white)
                            Text("120 hotels near your destination").font(.custom("Helvetica", size:17)).fontWeight(.regular).foregroundColor(Color("pinkfont"))
                        }.padding().margin(left: 10)
                }
                  
                }.frame(height: 200)
              
                ScrollView{
                    ForEach(hotels, id: \.id) { hotel in
                        NavigationLink(destination: hotelDetails()){  hotelcard(name: hotel.name, location:hotel.location, price: hotel.price, image: hotel.image)
                        }.buttonStyle(.plain)
                    }.margin(top: 30)
                          }
                  
              
            }.background(Color("backgroundPink"))
        }
    }
    


struct HotleList_Previews: PreviewProvider {
    static var previews: some View {
        HotleList()
    }
}
