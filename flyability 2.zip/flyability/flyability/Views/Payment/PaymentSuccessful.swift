//
//  PaymentSuccessful.swift
//  flyability
//
//  Created by duaa mohammed on 06/11/2022.
//

import SwiftUI

struct PaymentSuccessful: View {
    @State private  var isActive = false
    var body: some View {
        
        if isActive{
            AssistantText()
        }
        else{
            
            VStack {
                ZStack(alignment: .bottom){
                    Image("BGL").ignoresSafeArea()
                    Image("camera").margin(bottom: 30,right: 160)
                    
                } //zstack line14
                
                ScrollView{
                    
                    
                    Text("Your payment was done Successfully")
                        .font(.largeTitle)
                        .fontWeight(.medium)
                        .foregroundColor(Color("fontGray"))
                        .multilineTextAlignment(.center).frame(width:300)
                    LottieViewSucsess().frame(width: 320,height: 320,alignment: .center)
                    
                    
                    
                    
                    
                }//scrollview line19
                .frame(width: 400)
                
                
            }.onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+4.0){
                    withAnimation(){
                    
                        self.isActive=true
                        
                    }
                    
                }}
        }
                    
    }
}

struct PaymentSuccessful_Previews: PreviewProvider {
    static var previews: some View {
        PaymentSuccessful()
    }
}
