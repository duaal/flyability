//
//  payment.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

//

import SwiftUI
import SwiftUIMargin

struct Payment: View {
    var body: some View {
                ZStack{
                    
                    Image("wave")
                        .margin(bottom:610 )
                    Text("Payment information")
                        .font(.largeTitle)
                        .fontWeight(.regular)
                        .foregroundColor(Color.white)
                        .margin(bottom: 550)
              
                
                Text("Now you can make your payment  using apple pay.")
                        .font(.largeTitle)
                        .fontWeight(.regular)
                        .foregroundColor(Color(red: 0.416, green: 0.416, blue: 0.416)).frame(width: 300)
                    .multilineTextAlignment(.center)
                    .margin(bottom:250)
                    
                    Image("bill1")
                        .margin(top: 200)
                    
               
                        
                    
                        HStack{
                            Image(systemName: "apple.logo") .foregroundColor(Color.white)
                            NavigationLink(destination:PaymentSuccessful().navigationBarBackButtonHidden(true) ){
                                Text(" PAY WITH APPLE ")
                                    .font(.headline)
                                .foregroundColor(.white)}
                              
                            
                        } //Hstack
                     //label line 90
                     .padding()
                        .frame(width: 310, height: 40)
                        .background(Color.black)
                        .cornerRadius(9.0)//button87
                        .margin(top: 600)
                } //ZStack line 14
            
           // VStack{
          
                
          //  } //VStack line 35
            
            }
          
         // navigationview line13
    }

            struct Payment_Previews: PreviewProvider {
                static var previews: some View {
                    Payment()
                }
            }
        
