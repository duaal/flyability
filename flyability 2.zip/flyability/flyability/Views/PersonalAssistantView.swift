//
//  PersonalAssistantView.swift
//  flyability
//
//  Created by duaa mohammed on 30/10/2022.
//

import SwiftUI

struct PersonalAssistantView: View {
    var body: some View {

            
            VStack(alignment: .leading){
                ZStack(alignment: .center){
                    
                    imageBackground2()
                    Text("Now after finshing all you booking prosses you can choose an assestent that could serive your needs").font(.custom("Helvetica", size: 26)).bold().foregroundColor(Color.white).padding()
                    
                }.frame(height: 180)
                Text("PICK YOUR PERSONAL ASSISTANT…").font(.custom("Helvetica", size: 20)).bold().margin(top: 60,bottom: 10).foregroundColor(Color("FontColor")).frame(width: 300)
                    ScrollView{
                        NavigationLink(destination: AssistantText2()){
                            PaCard2(name:"Personal Assistant Name", description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ")}.buttonStyle(.plain)
                        NavigationLink(destination: AssistantText2()){
                            PaCard2(name:"Personal Assistant Name", description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ")}.buttonStyle(.plain)
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        PaCard2(name:"Personal Assistant Name", description:"some description")
                        
                        
                        
                    
                    
                    }.padding()
            }
        }
        
    
    
    struct PersonalAssistantView_Previews: PreviewProvider {
        static var previews: some View {
            PersonalAssistantView()
            
            
        }
    }
}
