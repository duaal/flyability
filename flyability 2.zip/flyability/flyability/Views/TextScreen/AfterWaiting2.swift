//
//  AfterWaiting2.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct AfterWaiting2: View {
    @State private var isActive = false
    var body: some View {
        if (isActive){
            
         Activities()}
        else{
    Waiting(text: "connecting you to your personal assistant ").onAppear{
        DispatchQueue.main.asyncAfter(deadline: .now()+6.0){
            withAnimation(){
            
                self.isActive=true
                
            }
            
        }}
            }
    }
    }




struct AfterWaiting2_Previews: PreviewProvider {
    static var previews: some View {
        AfterWaiting2()
    }
}
