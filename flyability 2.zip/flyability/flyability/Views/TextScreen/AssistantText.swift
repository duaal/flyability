//
//  AssistantText.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct AssistantText: View {
    var body: some View {
        
           
                VStack {
                    ZStack(alignment: .bottom){
                        Image("BGL").ignoresSafeArea()
                        Image("camera").margin(bottom: 30,right: 160)
                        
                    } //zstack line14
                        
                    ScrollView{
                    
                        
                        Text("Now after we have finshed all the Booking catigorries I’ll be shearing with you some informations about the people that will assist you in paris …")
                            .font(.largeTitle)
                            .fontWeight(.medium)
                            .foregroundColor(Color("fontGray"))
                            .multilineTextAlignment(.center).frame(width:300)
                            
                          
                        HStack{
                            Image("clouds").margin(top:10,right:280)
                            
                            
                        }//hstack line33
                        NavigationLink(destination: PersonalAssistantView().navigationBarBackButtonHidden(true)){
                            Text("Next").bold()
                        }
                        HStack{
                            Image("mic")
                                .margin(left:300)
                        }//hstack line39

                    }//scrollview line19
                    .frame(width: 400)
                    
                    
                }
            }
    
}

struct AssistantText_Previews: PreviewProvider {
    static var previews: some View {
        AssistantText()
    }
}
