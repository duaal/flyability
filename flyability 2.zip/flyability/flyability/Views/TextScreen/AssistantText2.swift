//
//  AssistantText2.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct AssistantText2: View {
    var body: some View {
        
            
               
                    VStack {
                        ZStack(alignment: .bottom){
                            Image("BGL").ignoresSafeArea()
                            Image("camera").margin(bottom: 30,right: 160)
                            
                        } //zstack line14
                            
                        ScrollView{
                        
                            
                            Text("you choose madlen right? …")
                                .font(.largeTitle)
                                .fontWeight(.medium)
                                .foregroundColor(Color("fontGray"))
                                .multilineTextAlignment(.center).frame(width:300)
                                
                              
                            HStack{
                                Image("clouds").margin(top:10,right:280)
                                
                                
                            }//hstack line33
                            NavigationLink(destination:Payment3().navigationBarBackButtonHidden(true)){
                                Text("Right").bold()
                            }
                            HStack{
                                Image("mic")
                                    .margin(left:300)
                            }//hstack line39

                        }//scrollview line19
                        .frame(width: 400)
                        
                        
                    }
                }
    }


struct AssistantText2_Previews: PreviewProvider {
    static var previews: some View {
        AssistantText2()
    }
}
