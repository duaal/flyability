//
//  ControlePageSlider2.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI
import SwiftUIMargin

struct ControlePageSlider2: View {
    @State private var pageIndex=0
    private let pages:[Page2]=Page2.samplePages
    private let dotAppearance=UIPageControl.appearance()
    var body: some View {
        NavigationView{
            ZStack{
                TabView(selection: $pageIndex){
                    ForEach(pages) { page in
                        VStack{
                            
                            modelpagw(page: page).frame(height: 845)
                            
                            if (page == pages.last){
                                    NavigationLink(destination:services() .navigationBarBackButtonHidden(true)){
                                        Text("Next").bold().margin(bottom: 120)}                 }else{
                                    Button("",action: incremetPage)
                                }
                        }.tag(page.tag)
                    }
                }.ignoresSafeArea().animation(.easeInOut,value: pageIndex ).tabViewStyle(.page).indexViewStyle(.page(backgroundDisplayMode: .interactive)).onAppear{
                    dotAppearance.currentPageIndicatorTintColor = .black
                    dotAppearance.pageIndicatorTintColor = .gray
                }
            }}}
        func incremetPage(){
            pageIndex += 1
        }
        func goToZero(){
            pageIndex = 0
        }
    }

struct ControlePageSlider2_Previews: PreviewProvider {
    static var previews: some View {
        ControlePageSlider2()
    }
}

