//
//  PageModel2.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import Foundation

struct Page2:Identifiable,Equatable{
    let id=UUID()
    var description:String
    var tag :Int
    
    static var samplePage = Page2(description: "here willl be the page description",tag: 0)
  static var samplePages:[Page2]=[
        Page2(description: "Hello Muhammed I’m  Sara I’ll be your personal assistant today  … Let me know littel bit about you to assist you better  …   ",tag: 0),
        Page2(description: " Great, I will be assistting you through your booking process for accommodation,flight, transportaion … ",tag: 1),
        Page2(description: "and a sim card or a wifi device depending on your preference so we can make sure that the connection is ok for us to assest you better abroad …",tag: 2)]
}
