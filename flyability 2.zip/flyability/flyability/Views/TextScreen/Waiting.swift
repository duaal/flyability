//
//  Waiting.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

//
//  Waiting.swift
//  Level 1
//
//  Created by Razan Aldossari on 11/04/1444 AH.
//

import SwiftUI
import SwiftUIMargin
struct Waiting: View {
    var text:String
var body: some View {
NavigationView {
VStack{
ZStack {
    Image("wave").ignoresSafeArea()
                                
    ZStack{
        VStack{
       
            Text(text)
                .font(.system(size: 40))
                .fontWeight(.bold)
                .foregroundColor(Color("darkgray"))
                .frame(width:380,height: 370)
                .margin(top:400,left: 0)
        }
        
    } //Zstack line17

    lottieViewLoading().frame(width: 320,height: 320,alignment: .center) .margin(top:800)
    
    Image("clouds")
    //    .resizable()
      //  .frame(width: 80, height: 50)
        .margin(top:1080,right: 240)
   
            }//Z Stack
                                
                    .frame(height: 200)
                    Spacer()
                              
                    } //VStack

               } //Navigation
    }
}

struct Waiting_Previews: PreviewProvider {
    static var previews: some View {
        Waiting(text:"We will find some one to assesit you\nshortly stay tooned")
    }
}
