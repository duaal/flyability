//
//  afterwaiting.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct afterwaiting: View {
    @State private var isActive = false
    var body: some View {
        if (isActive){
            
            ControlePageSlider2()}
        else{
    Waiting(text:"We will find some one to assesit you\nshortly stay tooned").onAppear{
        DispatchQueue.main.asyncAfter(deadline: .now()+6.0){
            withAnimation(){
            
                self.isActive=true
                
            }
            
        }}
            }
    }
}

struct afterwaiting_Previews: PreviewProvider {
    static var previews: some View {
        afterwaiting()
    }
}
