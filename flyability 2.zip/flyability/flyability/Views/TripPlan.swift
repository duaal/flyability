//
//  TripPlan.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct TripPlan: View {
    var body: some View {
        
            
    NavigationView {
      VStack{
        ZStack {
            Wave()

            
        ZStack{
                Button("OCT 11") {}
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.white)
                    .frame(width:150,height: 50)
                    .background(Color("purple"))
                    .cornerRadius(10)
                    .margin(top:320)

            
        Button{print("test")}
        label:{
            HStack{
                Image("one")
                VStack(alignment: .leading){
                    
                    //      .margin(right: 60)
                    
                    Text("Visit the louvre museum")
                        .font(.body)
                        .fontWeight(.heavy)
                        .foregroundColor(Color("darkgray"))
                    
                    Text("1:00pm - 3:30pm")
                        .font(.body)
                        .fontWeight(.heavy)
                        .foregroundColor(Color("purple"))
                    
                } //Vstack line 33
                 //  .margin(left:60)
                
                
            } //HStack line 31
            .margin(right: 45)
            .frame(width:340,height: 70)
            .background(Color("babyblue"))
            .cornerRadius(20)

            
        }//label
              .margin(top:500)
                
                
            Button{print("test")
                        }
              label:{
                  HStack{
                   Image("two")
                      VStack(alignment: .leading){
                          Text("BTS Concert")
                              .font(.body)
                              .fontWeight(.heavy)
                              .foregroundColor(Color("darkgray"))
                          
                          Text("1:00pm - 3:30pm")
                              .font(.body)
                              .fontWeight(.heavy)
                              .foregroundColor(Color("purple"))
                      }

                         } //Hstack
                  .margin(right: 100)
                    .frame(width:340,height: 70)
                    .background(Color("babyblue"))
                    .cornerRadius(20)
                         
                     } //label
              .margin(top:660)

            
    Button{print("test")
                        }
              label:{
                HStack{
                    Image("three")
                    VStack(alignment: .leading){
                        Text("longines global tour")
                            .font(.body)
                            .fontWeight(.heavy)
                            .foregroundColor(Color("darkgray"))
                        
                        Text("1:00pm - 3:30pm")
                            .font(.body)
                            .fontWeight(.heavy)
                            .foregroundColor(Color("purple"))
                    }
                         } //Hstack
                .margin(right: 80)
                    .frame(width:340,height: 70)
                    .background(Color("babyblue"))
                    .cornerRadius(20)
                  
              } //label
              .margin(top:820)
            
       
    Button{print("test")
                   }
         label:{
             HStack(){
               Image("four")
               VStack(alignment: .leading){
                   Text("Disneyland")
                       .font(.body)
                       .fontWeight(.heavy)
                       .foregroundColor(Color("darkgray"))
                   
                   Text("1:00pm - 3:30pm")
                       .font(.body)
                       .fontWeight(.heavy)
                       .foregroundColor(Color("purple"))
               }
                    } //Hstack
             .margin(right: 100)
                    .frame(width:340,height: 70)
                    .background(Color("babyblue"))
                    .cornerRadius(20)
                    
                } //label
         .margin(top:980)


        Button{print("test")
                }
            label:{
               HStack{
                    Image("five")
                   VStack(alignment: .leading){
                       Text("Le meurice resturent")
                           .font(.body)
                           .fontWeight(.heavy)
                           .foregroundColor(Color("darkgray"))
                       
                       
                       Text("1:00pm - 3:30pm")
                           .font(.body)
                           .fontWeight(.heavy)
                           .foregroundColor(Color("purple"))
                   }
              } //Hstack
               .margin(right: 75)
               .frame(width:340,height: 70)
               .background(Color("babyblue"))
               .cornerRadius(20)
               
            } //label
            .margin(top:1140)
                
                
            } //Zstack line18
            
            Image("PA2")
                .margin(right: 180)
            Text("My Trip Plan")
                .font(.title)
                .fontWeight(.heavy)
                .foregroundColor(Color.white)
                .margin(top: 180,right: 180)
            Image(systemName:"video.slash.fill")
                .resizable()
                .frame(width: 40, height: 30)
                .foregroundColor(Color("darkblue"))
                .margin(top: 90,right: 85)
            }//Z Stack
            
            .frame(height: 200)
                    Spacer()
          
         
                } //VStack
      // .navigationTitle("My Trip Plan")
       
       //  .foregroundColor(Color.gray)
            } //Navigation
            

        }
    }


struct TripPlan_Previews: PreviewProvider {
    static var previews: some View {
        TripPlan()
    }
}
