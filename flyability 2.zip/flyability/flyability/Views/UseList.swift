//
//  UseList.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct UseList: View {
    var body: some View {
        
            NavigationView{
                VStack{
                    ZStack {
                        Wave()
                        
                        ZStack{
                            
                            Button{print("test")}
                        label:{
                            
                            VStack(alignment: .leading){
                                Text("User #14")
                                    .font(.system(size: 20))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkblue"))
                                
                                Text("Mohamed Khalid - 10 OCT Paris")
                                    .font(.system(size: 20))
                                    .fontWeight(.regular)
                                    .foregroundColor(Color("darkgray"))
                                
                            } //Vstack line 22
                            
                            .margin(right: 20)
                            .frame(width:340,height: 80)
                            .background(Color("babyblue"))
                            .cornerRadius(20)
                            
                        }//label
                        .margin(top:350)
                            
                            Button{print("test")}
                        label:{
                            
                            VStack(alignment: .leading){
                                Text("User #34")
                                    .font(.system(size: 20))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkblue"))
                                
                                Text("Sara Adams - 3 NOV Lyon")
                                    .font(.system(size: 20))
                                    .fontWeight(.regular)
                                    .foregroundColor(Color("darkgray"))
                                
                            } //Vstack line 22
                            
                            .margin(right: 65)
                            .frame(width:340,height: 80)
                            .background(Color("babyblue"))
                            .cornerRadius(20)
                            
                        }//label
                        .margin(top:530)
                            
                            Button{print("test")}
                        label:{
                            
                            VStack(alignment: .leading){
                                Text("User #50")
                                    .font(.system(size: 20))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkblue"))
                                
                                Text("Tomas Jhon - 1 DEC Marseille")
                                    .font(.system(size: 20))
                                    .fontWeight(.regular)
                                    .foregroundColor(Color("darkgray"))
                                
                            } //Vstack line 22
                            
                            .margin(right: 35)
                            .frame(width:340,height: 80)
                            .background(Color("babyblue"))
                            .cornerRadius(20)
                            
                        }//label
                        .margin(top:710)
                            
                            Button{print("test")}
                        label:{
                            
                            VStack(alignment: .leading){
                                Text("User #100")
                                    .font(.system(size: 20))
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("darkblue"))
                                
                                Text("Manal Saad - 1 JAN Paris")
                                    .font(.system(size: 20))
                                    .fontWeight(.regular)
                                    .foregroundColor(Color("darkgray"))
                                
                            } //Vstack line 22
                            
                            .margin(right: 70)
                            .frame(width:340,height: 80)
                            .background(Color("babyblue"))
                            .cornerRadius(20)
                            
                        }//label
                        .margin(top:890)
                            
                            
                        } //Zstack line17
                        
                        Image("camera")
                            .resizable()
                            .frame(width: 140,height: 140)
                            .margin(right: 200)
                        Image("user")
                            .margin(bottom:25,left: 160)
                        Text("User List")
                            .font(.title)
                            .fontWeight(.heavy)
                            .foregroundColor(Color.white)
                            .margin(top: 180,right: 215)
                        Image(systemName:"video.slash.fill")
                            .resizable()
                            .frame(width: 40, height: 30)
                            .foregroundColor(Color("darkblue"))
                            .margin(top: 90,right: 120)
                        Image(systemName:"mic.fill")
                            .resizable()
                            .frame(width: 30, height: 50)
                            .foregroundColor(Color("darkblue"))
                            .margin(top:1300,left: 290)
                    }//Z Stack
                    
                    .frame(height: 200)
                    Spacer()
                    
                    
                } //VStack
                
            }
            
        }
    }


struct UseList_Previews: PreviewProvider {
    static var previews: some View {
        UseList()
    }
}
