//
//  animation.swift
//  flyability
//
//  Created by duaa mohammed on 02/11/2022.
//

import SwiftUI
import Lottie

struct animation: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct animation_Previews: PreviewProvider {
    static var previews: some View {
        animation()
    }
}
