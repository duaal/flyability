//
//  button.swift
//  flyability
//
//  Created by duaa mohammed on 01/11/2022.
//

import SwiftUI

struct button: View {
    var buttonLable:String;
    var body: some View {

        Text(buttonLable).font(.custom("SF-Pro", size: 20)).foregroundColor(Color.white).frame(width:300,height: 50).background(Color("buttonColor"))
    }
}

struct button_Previews: PreviewProvider {
    static var previews: some View {
        button(buttonLable: "Book this Activity")
    }
}
