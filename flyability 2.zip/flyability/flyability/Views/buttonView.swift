//
//  buttonView.swift
//  flyability
//
//  Created by duaa mohammed on 01/11/2022.
//

import SwiftUI

struct buttonView: View {
    var body: some View {
        Text("Book this Activity").font(.custom("SF-Pro", size: 20)).foregroundColor(Color.white).frame(width:304,height: 50).background(Color("buttonColor"))    }
}

struct buttonView_Previews: PreviewProvider {
    static var previews: some View {
        buttonView()
    }
}
