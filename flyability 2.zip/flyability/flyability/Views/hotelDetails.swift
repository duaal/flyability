//
//  hotelDetails.swift
//  flyability
//
//  Created by duaa mohammed on 01/11/2022.
//

import SwiftUI
import SwiftUIMargin
struct hotelDetails: View {
    var body: some View {
        VStack{
            ZStack(alignment:.bottomTrailing){
                imageSlider().frame(height:358)
                Image("camera").frame(width:200 )
            }.frame(height: 290).ignoresSafeArea()
            ScrollView{
                VStack(alignment:.leading){
                    Text("HOTEL NAME").font(.custom("Helvetica", size: 26)).bold().foregroundColor(Color("FontColor")).margin(top: 10,left: 15)
                    Text("DETAILS").font(.custom("Helvetica", size: 21)).bold().foregroundColor(Color("FontColor")).margin(top: 10,left: 15)
                    Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.").font(.custom("Helvetica", size: 12)).fontWeight(.regular).foregroundColor(Color("FontColor")).margin(top: 10,left: 15)
                    Text("AMENITIES").font(.custom("Helvetica", size: 21)).bold().foregroundColor(Color("FontColor")).margin(top: 10,left: 15)
                    HStack{Image("wi-fi");
                        Image("pool"); Image("restaurant")}.margin(top: 10,left: 15)
                    Text("Rooms").font(.custom("Helvetica", size: 21)).foregroundColor(Color("FontColor")).bold().margin(top: 10,left: 15)
                    Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, ").font(.custom("Helvetica", size: 12)).fontWeight(.regular).foregroundColor(Color("FontColor")).margin(top: 10,left: 15)
                    NavigationLink(destination: Payment()){
                        button(buttonLable: "Book This Room").margin(top: 20,left: 23).padding()
                    }}
                
                
            }
        }
    }
}

struct hotelDetails_Previews: PreviewProvider {
    static var previews: some View {
        hotelDetails()
    }
}
