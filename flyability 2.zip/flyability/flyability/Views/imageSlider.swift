//
//  imageSlider.swift
//  flyability
//
//  Created by duaa mohammed on 01/11/2022.
//

import SwiftUI

struct imageSlider: View {
    private let images = ["hotel1", "placholder","placholder", "placholder"]

    var body: some View {
        TabView {
             ForEach(images, id: \.self) { item in
                  //3
                  Image(item)
                     .resizable()
                     .ignoresSafeArea()
             }
        }
         .tabViewStyle(PageTabViewStyle())
    }
}

struct imageSlider_Previews: PreviewProvider {
    static var previews: some View {
        imageSlider()
    }
}
