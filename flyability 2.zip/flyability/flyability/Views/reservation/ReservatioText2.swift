//
//  ReservatioText2.swift
//  flyability
//
//  Created by duaa mohammed on 06/11/2022.
//

import SwiftUI

struct ReservatioText2: View {
    @State private var isActive = false

    var body: some View {
        if isActive{
            TripPlan()
        }
        else{
            VStack{
                ZStack {
                    Image("wave").ignoresSafeArea()
                    Image("PA2").margin(right: 200)
                    
                    ZStack{
                        VStack{
                            
                            Text("when you need to go through your plan any time just go to the app and say my trip plan and the AI will ask you about the day and will read it for you  …").multilineTextAlignment(.center)
                                .font(.system(size: 40))
                                .fontWeight(.bold)
                                .foregroundColor(Color("darkgray"))
                                .frame(width:370,height: 310)
                                .margin(top:500,left: 0)
                        }
                        
                    } //Zstack line17
                    
                    
                    Image("clouds")
                    //    .resizable()
                    //  .frame(width: 80, height: 50)
                        .margin(top:1080,right: 240)
                    
                }//Z Stack
                
                .frame(height: 200)
                Spacer()
                
            }.onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+10.0){
                    withAnimation(){
                    
                        self.isActive=true
                        
                    }
                    
                }}
        }
    }
}

struct ReservatioText2_Previews: PreviewProvider {
    static var previews: some View {
        ReservatioText2()
    }
}
