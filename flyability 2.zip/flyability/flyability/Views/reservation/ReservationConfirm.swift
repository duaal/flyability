//
//  ReservationConfirm.swift
//  flyability
//
//  Created by duaa mohammed on 06/11/2022.
//

import SwiftUI
import SwiftUIMargin

struct ReservationConfirm: View {
    @State private var isActive = false
    var body: some View {
        
        if isActive{
            ReservationText()
        }
        else{
            VStack{
                ZStack {
                    Image("wave").ignoresSafeArea()
                    Image("PA2").margin(right: 200)
                    
                    ZStack{
                        VStack{
                            
                            Text("the resirvation is comfirmed …")
                                .font(.system(size: 40))
                                .fontWeight(.bold)
                                .foregroundColor(Color("darkgray"))
                                .frame(width:380,height: 370)
                                .margin(top:400,left: 0)
                        }
                        
                    } //Zstack line17
                    
                    LottieViewSucsess().frame(width: 320,height: 320,alignment: .center) .margin(top:800)
                    
                    Image("clouds")
                    //    .resizable()
                    //  .frame(width: 80, height: 50)
                        .margin(top:1080,right: 240)
                    
                }//Z Stack
                
                .frame(height: 200)
                Spacer()
                
            }.onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+4.0){
                    withAnimation(){
                    
                        self.isActive=true
                        
                    }
                    
                }} //VStack
            
            //Navigation
        }}
    }


struct ReservationConfirm_Previews: PreviewProvider {
    static var previews: some View {
        ReservationConfirm()
    }
}
