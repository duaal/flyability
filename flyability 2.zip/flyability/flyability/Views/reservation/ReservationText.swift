//
//  ReservationText.swift
//  flyability
//
//  Created by duaa mohammed on 06/11/2022.
//

import SwiftUI

struct ReservationText: View {
    @State private var isActive = false
    var body: some View {
        if isActive{
            ReservatioText2()
        }
        else{
            VStack{
                ZStack {
                    Image("wave").ignoresSafeArea()
                    Image("PA2").margin(right: 200)
                    
                    ZStack{
                        VStack{
                            
                            Text("Now after planing all your trip I’ll leave you and I’ll assist you agin at the day of your flight …").multilineTextAlignment(.center)
                                .font(.system(size: 40))
                                .fontWeight(.bold)
                                .foregroundColor(Color("darkgray"))
                                .frame(width:370,height: 310)
                                .margin(top:500,left: 0)
                        }
                        
                    } //Zstack line17
                    
                    
                    Image("clouds")
                    //    .resizable()
                    //  .frame(width: 80, height: 50)
                        .margin(top:1080,right: 240)
                    
                }//Z Stack
                
                .frame(height: 200)
                Spacer()
                
            }.onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+7.0){
                    withAnimation(){
                    
                        self.isActive=true
                        
                    }
                    
                }}}
    }
}

struct ReservationText_Previews: PreviewProvider {
    static var previews: some View {
        ReservationText()
    }
}
