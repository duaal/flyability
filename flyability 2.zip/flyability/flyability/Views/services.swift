//
//  services.swift
//  flyability
//
//  Created by duaa mohammed on 03/11/2022.
//

import SwiftUI

struct services: View {
    var body: some View {
        NavigationView{
            VStack{
                ZStack{
                    
                    Image("wave (1)")
                        .margin(bottom: 110)
                    
                    Image("camera")
                        .margin(right: 200)
                    
                    Image(systemName:"video.slash.fill")
                        .resizable()
                        .frame(width: 40 , height: 30)
                        .margin(top: 90 , right: 100 )
                        .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                    
                    Image(systemName:"mic.fill")
                        .resizable()
                        .frame(width: 20 , height: 30)
                        .foregroundColor(Color(red: 0.309, green: 0.443, blue: 0.771))
                        .margin( top: 200 ,left: 300)
                    
                }.frame(height: 250)
                ScrollView{
                    NavigationLink(destination:Flight()){
                        VStack(alignment: .leading){
                            Text("FLIGHT")
                                .foregroundColor(Color(red: 0.416, green: 0.416, blue: 0.416))
                                .multilineTextAlignment(.leading)
                                .padding(.horizontal)
                            
                            Text("here you can pick your flight for your next destination.")
                                .fontWeight(.thin)
                                .foregroundColor(Color(red: 0.416, green: 0.416, blue: 0.416))
                                .multilineTextAlignment(.leading).frame(width:290,height: 50)
                        }
                        .padding()}
                    
                    
                    
                    .foregroundColor(Color.white)
                    .background(Color("babyblue"))
                    .cornerRadius(8)
                    
                    NavigationLink(destination:Calender2()){
                        VStack(alignment: .leading){
                            Text("HOTEL")
                                .foregroundColor(Color(red: 0.416, green: 0.416, blue: 0.416))
                                .multilineTextAlignment(.leading)
                                .padding(.horizontal)
                            
                            Text(/*@START_MENU_TOKEN@*/"from here, you can make your reservation for a hotel."/*@END_MENU_TOKEN@*/)
                                .fontWeight(.thin)
                                .foregroundColor(Color(red: 0.416, green: 0.416, blue: 0.416))
                                .multilineTextAlignment(.leading).frame(width:290 ,height: 50)
                        }
                        .padding()
                        
                    }
                    
                    .foregroundColor(Color.white)
                    .background(Color("babyblue"))
                    .cornerRadius(8)
                    
                    
                    
                    
                    .foregroundColor(Color.white)
                    .background(Color("babyblue"))
                    .cornerRadius(8)
                    
                    
                    
                    .foregroundColor(Color.white)
                    .background(Color("babyblue"))
                    .cornerRadius(8)}
            }
        }
    }
}
struct services_Previews: PreviewProvider {
    static var previews: some View {
        services()
    }
}
