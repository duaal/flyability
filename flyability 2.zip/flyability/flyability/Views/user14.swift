//
//  user14.swift
//  flyability
//
//  Created by duaa mohammed on 05/11/2022.
//

import SwiftUI

struct user14: View {
    var body: some View {
        
    NavigationView {
    VStack{
    ZStack {
        Wave()
                            
    ZStack{
                            
    Button{print("test")}
            label:{
                
        VStack(alignment: .leading){
            Text("FLIGHT")
                .font(.system(size: 20))
                .fontWeight(.bold)
                .foregroundColor(Color("darkgray"))
                                    
            Text("10 OCT to Paris aravile time 10:00 am")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
            Text("Gate 10 Terminal 7 france airways")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
                                    
                } //Vstack line 22
             
                .margin(right: 10)
                .frame(width:360,height: 110)
                .background(Color("babyblue"))
                .cornerRadius(5)
             
                }//label
                .margin(top:380)
                                
        Button{print("test")}
                label:{
                    
            VStack(alignment: .leading){
                Text("HOTEL")
                .font(.system(size: 20))
                .fontWeight(.bold)
                .foregroundColor(Color("darkgray"))
                                        
                Text("from here, you can make your ")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
                Text("reservation for a hotel.")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
                    
                    } //Vstack line 50
                    .margin(right: 70)
                    .frame(width:360,height: 110)
                    .background(Color("babyblue"))
                    .cornerRadius(5)
                    
                 
                    }//label
                    .margin(top:620)
        
        Button{print("test")}
                label:{
                    
            VStack(alignment: .leading){
                Text("SIM CARD AND WI-FI")
                .font(.system(size: 20))
                .fontWeight(.bold)
                .foregroundColor(Color("darkgray"))
                                        
                Text("from here, you can book a SIM card.")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
                
                    
                    } //Vstack line 78
                    .margin(right: 20)
                    .frame(width:360,height: 110)
                    .background(Color("babyblue"))
                    .cornerRadius(5)
                    
                    }//label
                    .margin(top:860)

        Button{print("test")}
                label:{
                    
            VStack(alignment: .leading){
                Text("Tranportaion")
                .font(.system(size: 20))
                .fontWeight(.bold)
                .foregroundColor(Color("darkgray"))
                                        
                Text("from here, you can book a taxi ")
                .font(.system(size: 19))
                .fontWeight(.regular)
                .foregroundColor(Color("darkgray"))
                Text("to drive you.")
                    .font(.system(size: 19))
                    .fontWeight(.regular)
                    .foregroundColor(Color("darkgray"))
                    
                    } //Vstack line 78
                    .margin(right: 70)
                    .frame(width:360,height: 110)
                    .background(Color("babyblue"))
                    .cornerRadius(5)
                    

                    }//label
                    .margin(top:1100)



               } //Zstack line17
                            
            Image("camera")
                .resizable()
                .frame(width: 140,height: 140)
                .margin(right: 200)
            Image("user")
                .margin(bottom:25,left: 160)
            Text("User #14")
                .font(.title)
                .fontWeight(.heavy)
                .foregroundColor(Color.white)
                .margin(top: 180,right: 215)
            Image(systemName:"video.slash.fill")
                .resizable()
                .frame(width: 40, height: 30)
                .foregroundColor(Color("darkblue"))
                .margin(top: 90,right: 120)
            Image(systemName:"mic.fill")
                .resizable()
                .frame(width: 30, height: 50)
                .foregroundColor(Color("darkblue"))
                .margin(top:1300,left: 290)
                }//Z Stack
                            
                .frame(height: 200)
                Spacer()
                          
                } //VStack

           } //Navigation
        
    }
}

struct user14_Previews: PreviewProvider {
    static var previews: some View {
        user14()
    }
}
