//
//  launchScreen.swift
//  flyability
//
//  Created by duaa mohammed on 02/11/2022.
//

import SwiftUI

struct launchScreen: View {
    @State private var isActive = false
    var body: some View {
        if (isActive){
            
            ControlePageSlider()}
        else{
        VStack{
            lottieView().frame(width: 320,height: 320,alignment: .center)    }.onAppear{
                DispatchQueue.main.asyncAfter(deadline: .now()+6.0){
                    withAnimation(){
                    
                        self.isActive=true
                        
                    }
                    
                }}
            }}
}

struct launchScreen_Previews: PreviewProvider {
    static var previews: some View {
        launchScreen()
    }
}
