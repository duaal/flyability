//
//  lottieView.swift
//  flyability
//
//  Created by duaa mohammed on 02/11/2022.
//

import Lottie
import SwiftUI
import UIKit
struct lottieView:UIViewRepresentable{

    
    typealias UIViewType = UIView
    
    func makeUIView(context:UIViewRepresentableContext<lottieView>) -> UIView {
        let view = UIView(frame:.zero)
        
        let animationView = LottieAnimationView()
        animationView.animation=Animation.named("airplane")
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.play()
        view.addSubview(animationView)
        animationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            animationView.widthAnchor.constraint(equalTo: view.widthAnchor),
            animationView.heightAnchor.constraint(equalTo: view.heightAnchor)
        ])
        
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        
    }
}


