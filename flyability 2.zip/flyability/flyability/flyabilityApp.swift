//
//  flyabilityApp.swift
//  flyability
//
//  Created by duaa mohammed on 26/10/2022.
//

import SwiftUI

@main
struct flyabilityApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
