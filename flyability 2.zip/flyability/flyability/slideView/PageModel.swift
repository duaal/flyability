//
//  PageModel.swift
//  flyability
//
//  Created by duaa mohammed on 02/11/2022.
//

import Foundation

struct Page:Identifiable,Equatable{
    let id=UUID()
    var description:String
    var tag :Int
    
    static var samplePage = Page(description: "here willl be the page description",tag: 0)
  static var samplePages:[Page]=[
        Page(description: "Welcome to FlyAbility We are a Travel App for people with physical and mental Disabilities. slide for next page ",tag: 0),
        Page(description: "With FlyAbility we will make sure that you will have a Great Travelling  experience by providing you with a professional personal assistant 24/7 during your trip. slide for next page",tag: 1),
        Page(description: "OK, Great. Let me take you to the login screen.",tag: 2)]
}
