//
//  login.swift
//  flyability
//
//  Created by duaa mohammed on 03/11/2022.
//

import SwiftUI
import SwiftUIMargin
struct login: View {
    @State var username: String = ""
    @State var password: String = ""
    var body: some View {
        NavigationView{
            VStack{
                ZStack{
                    Image("wave")
                        .ignoresSafeArea()
                    
                    ZStack{
                        
                        
                        Text(" Log in ")
                            .font(.title)
                            .fontWeight(.medium)
                        //     .multilineTextAlignment(.leading)
                            .foregroundColor(Color.black)
                            .margin(top: 500,right: 250)
                        
                        
                        
                        
                        
                    }//Zstack line 18
                    Image("logo")
                        .margin(top: 200)
                    
                    
                } //ZStack line 14
                .frame(height: 200)
                
                ScrollView{
                    
                    Text("Username")
                        .fontWeight(.thin)
                        .multilineTextAlignment(.leading)
                        .margin(right: 250)
                    
                    TextField("Username", text: $username)
                        .padding(.all)
                        .background(Color("babygray"))
                        .cornerRadius(9.0)
                        .frame(width: 350)
                    
                    Text("Password")
                        .fontWeight(.thin)
                        .multilineTextAlignment(.leading)
                        .margin(right: 250)
                    
                    SecureField("Password", text: $password)
                        .padding()
                        .background(Color("babygray"))
                        .cornerRadius(9.0)
                        .padding(.bottom, 20)
                        .frame(width: 350)
                    
                    HStack{
                        Text("Forget Password?")
                            .fontWeight(.thin)
                            .margin(bottom: 30,right: 200)
                        
                    } //HStack line 70
                    
                    
                    Button(action: {print("Button tapped")}) {
                        // LoginButtonContent()
                        Text(" CREATE AN ACCOUNT ")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 350, height: 40)
                            .background(Color("TR"))
                            .cornerRadius(9.0)
                    } //button line74
                    NavigationLink(destination: FaceId().navigationBarBackButtonHidden(true)){
                        Text("SIGN IN WITH FACE ID")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 350, height: 40)
                            .background(Color("TR"))
                        .cornerRadius(9.0)}
                    Button(action: {} ){
                        
                        
                        HStack{
                            Image(systemName: "apple.logo") .foregroundColor(Color.white)
                            
                            Text(" SIGN IN WITH APPLE ")
                                .font(.headline)
                                .foregroundColor(.white)
                            
                            
                        } //Hstack
                        //label line 90
                    }  .padding()
                        .frame(width: 350, height: 40)
                        .background(Color.black)
                        .cornerRadius(9.0)//button87
                    
                    Button(action: {print("Button tapped")}) {
                        // LoginButtonContent()
                        
                    }
                }//ScrollView line45
                .margin(top: 200)
                
            } //VStack line 13
        }
    }
}

struct login_Previews: PreviewProvider {
    static var previews: some View {
        login()
    }
}
