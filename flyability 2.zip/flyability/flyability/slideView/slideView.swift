//
//  slideView.swift
//  flyability
//
//  Created by duaa mohammed on 02/11/2022.
//

import SwiftUI

struct slideView: View {
    var page:Page
    var body: some View {
        
        VStack {
            ZStack{
                Image("BGL").ignoresSafeArea()
                
            } //zstack line14
                
            ScrollView{
            
                
                Text(page.description)
                    .font(.largeTitle)
                    .fontWeight(.medium)
                    .foregroundColor(Color("fontGray"))
                    .multilineTextAlignment(.center).frame(width:300)
                    
                  
                HStack{
                    Image("clouds").margin(top:10,right:280)
                    
                    
                }//hstack line33
                
                HStack{
                    Image("mic")
                        .margin(left:300)
                }//hstack line39

            }//scrollview line19
            .frame(width: 400)
            
            
        }
    }
}

struct slideView_Previews: PreviewProvider {
    static var previews: some View {
        slideView(page:Page.samplePage)
    }
}
